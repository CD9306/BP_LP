import { PartnerRecord } from '../data/partners';

interface DatenschutzProps {
  partnerData: PartnerRecord;
}

export function Datenschutz({ partnerData }: DatenschutzProps) {
  return (
    <div className="prose prose-sm max-w-none">
      <h3 className="text-xl font-bold text-[#232D3E] mb-4">Datenschutzrichtlinie für Landingpages externer Vertriebspartner</h3>

      <p className="text-sm text-gray-600 mb-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
        <strong>HINWEIS:</strong> Diese Datenschutzrichtlinie gilt für von BestPrime bereitgestellte Landingpages externer Vertriebspartner.
      </p>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">1. Verantwortlicher für die Datenverarbeitung</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Verantwortlich im Sinne der Datenschutz-Grundverordnung (DSGVO) für den Betrieb dieser Landingpage ist:
        </p>
        <p className="mb-3">
          <strong>BestPrime GmbH</strong><br />
          Leopoldstraße 31<br />
          80802 München<br />
          Deutschland
        </p>
        <p className="mb-3">
          Telefon: +49 89 277 827 052<br />
          E-Mail: <a href="mailto:office@bestprime.com" className="text-[#00A3DE] hover:underline">office@bestprime.com</a>
        </p>
        <p className="mb-3 text-gray-700">
          Weitere Informationen findest du unter:{' '}
          <a href="https://bestprime.com/impressum" target="_blank" rel="noopener noreferrer" className="text-[#00A3DE] hover:underline">
            https://bestprime.com/impressum
          </a>
        </p>
      </div>

      <div className="mb-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">2. Externer Vertriebspartner</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Die über diese Landingpage erhobenen personenbezogenen Daten werden zusätzlich an folgenden externen Vertriebspartner weitergeleitet:
        </p>
        <p className="mb-3">
          <strong>{partnerData.company_or_name}</strong>
          {partnerData.legal_representative && (
            <>
              <br />
              {partnerData.legal_representative}
            </>
          )}
          <br />
          {partnerData.street}<br />
          {partnerData.zip} {partnerData.city}
          {partnerData.country && (
            <>
              <br />
              {partnerData.country}
            </>
          )}
        </p>
        <p className="mb-3">
          {partnerData.phone && (
            <>
              Telefon: {partnerData.phone}<br />
            </>
          )}
          {partnerData.mobile && (
            <>
              Mobil: {partnerData.mobile}<br />
            </>
          )}
          E-Mail: <a href={`mailto:${partnerData.email}`} className="text-[#00A3DE] hover:underline">{partnerData.email}</a>
        </p>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Der Vertriebspartner verarbeitet deine personenbezogenen Daten eigenverantwortlich zur Kontaktaufnahme, Beratung, Angebotserstellung sowie zur Vertragsanbahnung oder -durchführung.
        </p>
        <p className="mb-0 text-gray-700 leading-relaxed">
          Je nach vertraglicher Ausgestaltung erfolgt die Verarbeitung entweder:
        </p>
        <ul className="list-disc list-inside ml-4 mt-2 text-gray-700">
          <li>in gemeinsamer Verantwortlichkeit gemäß Art. 26 DSGVO oder</li>
          <li>als Übermittlung an einen eigenständig Verantwortlichen.</li>
        </ul>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">3. Bereitstellung der Landingpage</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Die Landingpage wird technisch durch die BestPrime GmbH bereitgestellt und betrieben. BestPrime stellt die IT-Infrastruktur, das Hosting sowie die eingesetzten Tracking- und Analyse-Tools zur Verfügung.
        </p>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">4. Erhebung personenbezogener Daten beim Besuch der Landingpage</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Bei der rein informatorischen Nutzung der Landingpage erhebt BestPrime automatisch folgende Daten:
        </p>
        <ul className="list-disc list-inside ml-4 text-gray-700 space-y-1">
          <li>IP-Adresse (anonymisiert)</li>
          <li>Datum und Uhrzeit des Zugriffs</li>
          <li>Zeitzonendifferenz zur GMT</li>
          <li>Inhalt der Anfrage</li>
          <li>HTTP-Statuscode</li>
          <li>Übertragene Datenmenge</li>
          <li>Referrer-URL</li>
          <li>Browsertyp und -version</li>
          <li>Betriebssystem</li>
          <li>Spracheinstellungen</li>
        </ul>
        <p className="mt-3 text-gray-700">
          Rechtsgrundlage ist Art. 6 Abs. 1 lit. f DSGVO.
        </p>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">5. Cookies und vergleichbare Technologien</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Diese Landingpage verwendet Cookies sowie vergleichbare Technologien (z. B. Local Storage), um die Funktionalität und Sicherheit zu gewährleisten sowie statistische Auswertungen zu ermöglichen.
        </p>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Du kannst die Speicherung von Cookies jederzeit über deine Browser-Einstellungen steuern.
        </p>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">6. Webanalyse- und Marketing-Tools</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Sofern eine entsprechende Einwilligung erteilt wurde, können insbesondere folgende Tools eingesetzt werden:
        </p>
        <ul className="list-disc list-inside ml-4 text-gray-700 space-y-1">
          <li>Google Analytics</li>
          <li>Google Tag Manager</li>
          <li>Google Ads / Conversion Tracking</li>
          <li>Google Remarketing</li>
          <li>Google Fonts</li>
          <li>Matomo (On-Premise)</li>
          <li>WordPress Stats</li>
        </ul>
        <p className="mt-3 text-gray-700">
          Rechtsgrundlage ist Art. 6 Abs. 1 lit. a DSGVO oder Art. 6 Abs. 1 lit. f DSGVO.
        </p>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">7. Verarbeitung personenbezogener Daten bei Kontaktaufnahme</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Wenn du über diese Landingpage Kontakt aufnimmst oder ein Formular ausfüllst, verarbeiten wir insbesondere:
        </p>
        <ul className="list-disc list-inside ml-4 text-gray-700 space-y-1">
          <li>Vor- und Nachname</li>
          <li>E-Mail-Adresse</li>
          <li>Telefonnummer</li>
          <li>Unternehmensname (optional)</li>
          <li>Inhalt der Anfrage</li>
        </ul>
        <p className="mt-3 text-gray-700 leading-relaxed">
          Diese Daten werden an den zuständigen Vertriebspartner weitergeleitet.
        </p>
        <p className="mt-3 text-gray-700">
          Rechtsgrundlage ist Art. 6 Abs. 1 lit. b DSGVO oder Art. 6 Abs. 1 lit. a DSGVO.
        </p>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">8. Weitergabe personenbezogener Daten</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Eine Weitergabe personenbezogener Daten erfolgt an:
        </p>
        <ul className="list-disc list-inside ml-4 text-gray-700 space-y-1">
          <li>den oben genannten Vertriebspartner</li>
          <li>technische Dienstleister von BestPrime (Auftragsverarbeiter)</li>
          <li>Behörden, sofern gesetzlich erforderlich</li>
        </ul>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">9. Speicherdauer</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Personenbezogene Daten werden nur so lange gespeichert, wie dies für die jeweiligen Zwecke erforderlich ist oder gesetzliche Aufbewahrungspflichten bestehen.
        </p>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">10. Rechte der betroffenen Personen</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit, Widerspruch sowie Widerruf erteilter Einwilligungen.
        </p>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Zudem besteht ein Beschwerderecht bei einer Datenschutzaufsichtsbehörde.
        </p>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">11. Kontakt Datenschutz</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Datenschutzanfragen kannst du richten an:
        </p>
        <p className="mb-3">
          <strong>BestPrime GmbH</strong><br />
          E-Mail: <a href="mailto:office@bestprime.com" className="text-[#00A3DE] hover:underline">office@bestprime.com</a>
        </p>
        <p className="mb-3 text-gray-700 leading-relaxed">
          sowie alternativ an den jeweiligen Vertriebspartner:<br />
          <a href={`mailto:${partnerData.email}`} className="text-[#00A3DE] hover:underline">{partnerData.email}</a>
        </p>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">12. Aktualisierung der Datenschutzerklärung</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Diese Datenschutzerklärung wird bei rechtlichen oder technischen Änderungen angepasst.
        </p>
      </div>

      <div className="text-sm text-gray-500 mt-8 pt-4 border-t border-gray-200">
        <p>Zuletzt aktualisiert: {new Date().getFullYear()}</p>
      </div>
    </div>
  );
}
