import { PartnerRecord } from '../data/partners';

export function normalizePhoneNumber(phoneNumber: string): string {
  const digitsOnly = phoneNumber.replace(/\D/g, '');

  if (digitsOnly.startsWith('00')) {
    return digitsOnly.substring(2);
  }

  return digitsOnly;
}

export function buildWhatsAppLink(phoneNumber: string): string {
  const normalized = normalizePhoneNumber(phoneNumber);
  return `https://wa.me/${normalized}`;
}

export function getWhatsAppUrl(partnerData: PartnerRecord): string | null {
  const phoneNumber = partnerData.mobile || partnerData.phone;
  if (phoneNumber) {
    return buildWhatsAppLink(phoneNumber);
  }

  return null;
}

export function getPartnerFirstName(partnerData: PartnerRecord): string {
  if (partnerData.company_or_name) {
    const firstPart = partnerData.company_or_name.split(' ')[0];
    return firstPart;
  }
  return 'dort';
}

export function getWhatsAppUrlWithMessage(partnerData: PartnerRecord): string | null {
  const phoneNumber = partnerData.mobile || partnerData.phone;
  if (!phoneNumber) {
    return null;
  }

  const normalized = normalizePhoneNumber(phoneNumber);
  const firstName = getPartnerFirstName(partnerData);
  const message = `Hi ${firstName},`;
  const encodedMessage = encodeURIComponent(message);

  return `https://wa.me/${normalized}?text=${encodedMessage}`;
}
