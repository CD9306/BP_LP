import { createContext, useContext, useState, ReactNode } from 'react';
import { PartnerRecord, getPartnerByCustomerNumber } from '../data/partners';

interface PartnerDataContextType {
  partner: PartnerRecord | null;
  loading: boolean;
  error: string | null;
  loadPartner: (customerNumber: string) => Promise<void>;
}

const PartnerDataContext = createContext<PartnerDataContextType | undefined>(undefined);

export function PartnerDataProvider({ children }: { children: ReactNode }) {
  const [partner, setPartner] = useState<PartnerRecord | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadPartner = async (customerNumber: string) => {
    setLoading(true);
    setError(null);

    try {
      const data = await getPartnerByCustomerNumber(customerNumber);

      if (!data) {
        setError(`Vertriebspartner "${customerNumber}" nicht gefunden oder nicht aktiv.`);
        setPartner(null);
      } else {
        setPartner(data);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Laden der Partnerdaten';
      console.error('loadPartner error:', err);
      setError(errorMessage);
      setPartner(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <PartnerDataContext.Provider
      value={{
        partner,
        loading,
        error,
        loadPartner,
      }}
    >
      {children}
    </PartnerDataContext.Provider>
  );
}

export function usePartnerData() {
  const context = useContext(PartnerDataContext);
  if (context === undefined) {
    throw new Error('usePartnerData must be used within a PartnerDataProvider');
  }
  return context;
}
