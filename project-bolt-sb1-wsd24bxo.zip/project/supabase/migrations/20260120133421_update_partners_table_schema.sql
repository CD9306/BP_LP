/*
  # Update partners table schema

  1. Changes
    - Rename company_name to company_or_name for consistency
    - Add active column for partner status
    - Update example data

  2. Notes
    - This migration updates the schema to match the new requirements
*/

-- Rename company_name to company_or_name if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'partners' AND column_name = 'company_name'
  ) THEN
    ALTER TABLE partners RENAME COLUMN company_name TO company_or_name;
  END IF;
END $$;

-- Add active column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'partners' AND column_name = 'active'
  ) THEN
    ALTER TABLE partners ADD COLUMN active boolean DEFAULT true;
  END IF;
END $$;

-- Update existing office example data
UPDATE partners
SET
  company_or_name = 'Max Mustermann',
  contact_name = 'Max Mustermann',
  email = 'max@mustermann.de',
  street = 'Musterstraße 123',
  zip = '12345',
  city = 'Musterstadt',
  country = 'Deutschland',
  phone = '+49 123 456789',
  mobile = '+49 170 1234567',
  legal_representative = 'Max Mustermann',
  website = 'https://www.mustermann.de',
  whatsapp_link = 'https://wa.me/491701234567',
  linkedin_link = 'https://www.linkedin.com/in/maxmustermann',
  calendly_link = 'https://calendly.com/maxmustermann',
  active = true
WHERE customer_number = 'office';
