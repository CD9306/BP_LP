import { X, MessageCircle, CheckCircle2 } from 'lucide-react';

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl: string | null;
  whatsappUrl: string | null;
  showThankYou?: boolean;
}

function isYouTubeUrl(url: string): boolean {
  return url.includes('youtube.com') || url.includes('youtu.be');
}

function isVimeoUrl(url: string): boolean {
  return url.includes('vimeo.com');
}

function getYouTubeEmbedUrl(url: string): string {
  const videoIdMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&?/]+)/);
  if (videoIdMatch) {
    return `https://www.youtube.com/embed/${videoIdMatch[1]}`;
  }
  return url;
}

function getVimeoEmbedUrl(url: string): string {
  const videoIdMatch = url.match(/vimeo\.com\/(\d+)/);
  if (videoIdMatch) {
    return `https://player.vimeo.com/video/${videoIdMatch[1]}`;
  }
  return url;
}

export function VideoModal({ isOpen, onClose, videoUrl, whatsappUrl, showThankYou = false }: VideoModalProps) {
  const handleWhatsAppClick = () => {
    if (whatsappUrl) {
      window.open(whatsappUrl, '_blank', 'noreferrer');
    }
  };

  if (!isOpen) return null;

  const renderVideo = () => {
    if (!videoUrl) {
      return (
        <div className="w-full aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
          <p className="text-gray-500">Kein Video verfügbar</p>
        </div>
      );
    }

    if (isYouTubeUrl(videoUrl)) {
      return (
        <div className="w-full aspect-video">
          <iframe
            src={getYouTubeEmbedUrl(videoUrl)}
            className="w-full h-full rounded-lg"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      );
    }

    if (isVimeoUrl(videoUrl)) {
      return (
        <div className="w-full aspect-video">
          <iframe
            src={getVimeoEmbedUrl(videoUrl)}
            className="w-full h-full rounded-lg"
            allow="autoplay; fullscreen; picture-in-picture"
            allowFullScreen
          />
        </div>
      );
    }

    return (
      <video
        controls
        className="w-full aspect-video rounded-lg bg-black"
        src={videoUrl}
      >
        Dein Browser unterstützt das Video-Tag nicht.
      </video>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl my-4 sm:my-8">
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200">
          <h2 className="text-lg sm:text-2xl font-bold text-[#232D3E] pr-2">Deine Videopräsentation</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors p-2 -m-2 flex-shrink-0"
          >
            <X size={20} className="sm:hidden" />
            <X size={24} className="hidden sm:block" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
          {showThankYou && (
            <div className="bg-green-50 border-2 border-green-500 rounded-xl p-4 sm:p-6">
              <div className="flex items-start gap-3 sm:gap-4">
                <div className="flex-shrink-0">
                  <CheckCircle2 className="text-green-500 sm:hidden" size={24} />
                  <CheckCircle2 className="text-green-500 hidden sm:block" size={28} />
                </div>
                <div>
                  <p className="text-green-800 font-semibold text-sm sm:text-lg leading-relaxed">
                    Vielen Dank für dein Vertrauen und herzlichen Glückwunsch für diese Entscheidung, wir haben das Video parallel als Link per Email gesendet.
                  </p>
                </div>
              </div>
            </div>
          )}

          {renderVideo()}

          <div className="space-y-2.5 sm:space-y-3">
            <button
              onClick={handleWhatsAppClick}
              disabled={!whatsappUrl}
              className={`w-full flex items-center justify-center gap-2.5 sm:gap-3 px-5 py-3.5 sm:px-6 sm:py-4 rounded-lg font-semibold text-base sm:text-lg transition-colors ${
                whatsappUrl
                  ? 'bg-[#25D366] hover:bg-[#1EBE57] text-white'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <MessageCircle size={20} className="sm:hidden flex-shrink-0" />
              <MessageCircle size={24} className="hidden sm:block flex-shrink-0" />
              <span className="text-sm sm:text-lg">{whatsappUrl ? 'Jetzt mit Berater chatten (WhatsApp)' : 'WhatsApp nicht verfügbar'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
