import { supabase } from '../lib/supabaseClient';

export type PartnerRecord = {
  id?: string;
  customer_number: string;
  company_or_name: string | null;
  street: string | null;
  zip: string | null;
  city: string | null;
  email: string | null;
  country: string | null;
  phone: string | null;
  mobile: string | null;
  website: string | null;
  vat_id: string | null;
  tax_id: string | null;
  register_court: string | null;
  register_number: string | null;
  contact_name: string | null;
  legal_representative: string | null;
  whatsapp_link: string | null;
  linkedin_link: string | null;
  calendly_link: string | null;
  video_url: string | null;
  privacy_contact_name: string | null;
  privacy_contact_email: string | null;
  active: boolean | null;
  created_at?: string;
  updated_at?: string;
};

export async function getPartnerByCustomerNumber(
  customerNumber: string
): Promise<PartnerRecord | null> {
  const { data, error } = await supabase
    .from('partners')
    .select('*')
    .eq('customer_number', customerNumber)
    .eq('active', true)
    .maybeSingle();

  if (error) {
    console.error('Supabase getPartnerByCustomerNumber error', error);
    return null;
  }
  return data ?? null;
}
