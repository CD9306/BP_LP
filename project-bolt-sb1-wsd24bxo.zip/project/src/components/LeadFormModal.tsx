import { useState, FormEvent } from 'react';
import { X, Loader2 } from 'lucide-react';

interface LeadFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  customerNumber: string;
  partnerName: string;
  flow?: 'cta1' | 'cta2_video';
}

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  message: string;
  teamSize: string;
  alreadyInSales: string;
  consent: boolean;
}

export function LeadFormModal({ isOpen, onClose, onSuccess, customerNumber, partnerName, flow = 'cta1' }: LeadFormModalProps) {
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    message: '',
    teamSize: '',
    alreadyInSales: '',
    consent: false,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;

    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    const webhookUrl = import.meta.env.VITE_LEAD_WEBHOOK_URL;

    if (!webhookUrl) {
      console.warn('VITE_LEAD_WEBHOOK_URL ist nicht konfiguriert');
      setError('Konfigurationsfehler: Webhook-URL fehlt. Bitte kontaktieren Sie den Support.');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        customerNumber,
        partnerName,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        message: formData.message,
        teamSize: formData.teamSize,
        alreadyInSales: formData.alreadyInSales,
        source: flow === 'cta2_video' ? 'cta2_video' : 'landingpage',
        timestamp: new Date().toISOString(),
      };

      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        message: '',
        teamSize: '',
        alreadyInSales: '',
        consent: false,
      });

      onSuccess();
    } catch (err) {
      console.error('Lead submission error:', err);
      setError('Senden fehlgeschlagen, bitte erneut versuchen.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  const modalTitle = flow === 'cta2_video' ? 'Videopräsentation anfordern' : 'Strategiegespräch anfragen';

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl my-4 sm:my-8">
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200">
          <h2 className="text-lg sm:text-2xl font-bold text-[#232D3E] pr-2">{modalTitle}</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors p-2 -m-2 flex-shrink-0"
            disabled={isSubmitting}
          >
            <X size={20} className="sm:hidden" />
            <X size={24} className="hidden sm:block" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-3 sm:space-y-4">
          <div className="grid sm:grid-cols-2 gap-3 sm:gap-4">
            <div>
              <label htmlFor="firstName" className="block text-xs sm:text-sm font-semibold text-[#232D3E] mb-1.5 sm:mb-2">
                Vorname <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="firstName"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                required
                className="w-full px-3 py-2.5 sm:px-4 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#00A3DE] focus:border-transparent transition-all"
                disabled={isSubmitting}
              />
            </div>

            <div>
              <label htmlFor="lastName" className="block text-xs sm:text-sm font-semibold text-[#232D3E] mb-1.5 sm:mb-2">
                Nachname <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="lastName"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                required
                className="w-full px-3 py-2.5 sm:px-4 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#00A3DE] focus:border-transparent transition-all"
                disabled={isSubmitting}
              />
            </div>
          </div>

          <div>
            <label htmlFor="email" className="block text-xs sm:text-sm font-semibold text-[#232D3E] mb-1.5 sm:mb-2">
              E-Mail <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="w-full px-3 py-2.5 sm:px-4 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#00A3DE] focus:border-transparent transition-all"
              disabled={isSubmitting}
            />
          </div>

          <div>
            <label htmlFor="phone" className="block text-xs sm:text-sm font-semibold text-[#232D3E] mb-1.5 sm:mb-2">
              Telefon <span className="text-red-500">*</span>
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
              className="w-full px-3 py-2.5 sm:px-4 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#00A3DE] focus:border-transparent transition-all"
              disabled={isSubmitting}
            />
          </div>

          <div>
            <label htmlFor="teamSize" className="block text-xs sm:text-sm font-semibold text-[#232D3E] mb-1.5 sm:mb-2">
              Wie viele Personen hast du im Team? <span className="text-red-500">*</span>
            </label>
            <select
              id="teamSize"
              name="teamSize"
              value={formData.teamSize}
              onChange={handleChange}
              required
              className="w-full px-3 py-2.5 sm:px-4 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#00A3DE] focus:border-transparent transition-all"
              disabled={isSubmitting}
            >
              <option value="">Bitte wählen</option>
              <option value="1-5">1-5</option>
              <option value="6-15">6-15</option>
              <option value="16-30">16-30</option>
              <option value="31-50">31-50</option>
              <option value="50+">50+</option>
            </select>
          </div>

          <div>
            <label htmlFor="alreadyInSales" className="block text-xs sm:text-sm font-semibold text-[#232D3E] mb-1.5 sm:mb-2">
              Warst du bereits im Vertrieb tätig? <span className="text-red-500">*</span>
            </label>
            <select
              id="alreadyInSales"
              name="alreadyInSales"
              value={formData.alreadyInSales}
              onChange={handleChange}
              required
              className="w-full px-3 py-2.5 sm:px-4 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#00A3DE] focus:border-transparent transition-all"
              disabled={isSubmitting}
            >
              <option value="">Bitte wählen</option>
              <option value="Ja">Ja</option>
              <option value="Ja, aber aktuell inaktiv">Ja, aber aktuell inaktiv</option>
              <option value="Nein, aber ich bin interessiert">Nein, aber ich bin interessiert</option>
            </select>
          </div>

          <div>
            <label htmlFor="message" className="block text-xs sm:text-sm font-semibold text-[#232D3E] mb-1.5 sm:mb-2">
              Notiz / Anliegen
            </label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              rows={3}
              className="w-full px-3 py-2.5 sm:px-4 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#00A3DE] focus:border-transparent transition-all resize-none"
              disabled={isSubmitting}
            />
          </div>

          <div className="flex items-start gap-2.5 sm:gap-3">
            <input
              type="checkbox"
              id="consent"
              name="consent"
              checked={formData.consent}
              onChange={handleChange}
              required
              className="mt-0.5 sm:mt-1 w-4 h-4 sm:w-4 sm:h-4 text-[#00A3DE] border-gray-300 rounded focus:ring-[#00A3DE] flex-shrink-0"
              disabled={isSubmitting}
            />
            <label htmlFor="consent" className="text-xs sm:text-sm text-gray-700 leading-snug">
              Ich willige ein, dass meine Daten zur Kontaktaufnahme verarbeitet werden. <span className="text-red-500">*</span>
            </label>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 sm:p-4">
              <p className="text-red-700 text-xs sm:text-sm">{error}</p>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-2.5 sm:gap-3 pt-2 sm:pt-4">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:flex-1 px-5 py-3 sm:px-6 sm:py-3 text-sm sm:text-base border-2 border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors order-2 sm:order-1"
              disabled={isSubmitting}
            >
              Abbrechen
            </button>
            <button
              type="submit"
              className="w-full sm:flex-1 px-5 py-3 sm:px-6 sm:py-3 text-sm sm:text-base bg-[#00A3DE] hover:bg-[#008BBC] text-white rounded-lg font-semibold transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-2 order-1 sm:order-2"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={18} className="animate-spin sm:hidden" />
                  <Loader2 size={20} className="animate-spin hidden sm:block" />
                  <span className="text-sm sm:text-base">Wird gesendet...</span>
                </>
              ) : (
                'Absenden'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
