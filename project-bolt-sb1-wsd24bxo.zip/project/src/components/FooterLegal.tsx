import { useState } from 'react';
import { LegalModal } from './LegalModal';
import { Impressum } from '../legal/Impressum';
import { Datenschutz } from '../legal/Datenschutz';
import { PartnerRecord } from '../data/partners';

interface FooterLegalProps {
  partnerData: PartnerRecord;
}

export function FooterLegal({ partnerData }: FooterLegalProps) {
  const [showImpressum, setShowImpressum] = useState(false);
  const [showDatenschutz, setShowDatenschutz] = useState(false);

  return (
    <>
      <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-gray-600">
        <button
          onClick={() => setShowImpressum(true)}
          className="hover:text-[#00A3DE] underline transition-colors"
        >
          Impressum
        </button>
        <span className="text-gray-400">|</span>
        <button
          onClick={() => setShowDatenschutz(true)}
          className="hover:text-[#00A3DE] underline transition-colors"
        >
          Datenschutz
        </button>
      </div>

      <LegalModal
        isOpen={showImpressum}
        onClose={() => setShowImpressum(false)}
        title="Impressum"
      >
        <Impressum partnerData={partnerData} />
      </LegalModal>

      <LegalModal
        isOpen={showDatenschutz}
        onClose={() => setShowDatenschutz(false)}
        title="Datenschutzerklärung"
      >
        <Datenschutz partnerData={partnerData} />
      </LegalModal>
    </>
  );
}
