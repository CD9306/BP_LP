import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { usePartnerData } from '../context/PartnerDataContext';
import { LandingPageContent } from '../components/LandingPageContent';

export function PartnerLandingPage() {
  const { customerNumber } = useParams<{ customerNumber: string }>();
  const { partner, loading, error, loadPartner } = usePartnerData();

  useEffect(() => {
    if (customerNumber) {
      loadPartner(customerNumber);
    }
  }, [customerNumber]);

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-[#00A3DE] mx-auto mb-4"></div>
          <p className="text-gray-600">Lade Partnerdaten...</p>
        </div>
      </div>
    );
  }

  if (!partner) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <h1 className="text-2xl font-bold text-[#232D3E] mb-4">Fehler beim Laden</h1>
          <p className="text-gray-600">{error || 'Partnerdaten konnten nicht geladen werden.'}</p>
        </div>
      </div>
    );
  }

  return <LandingPageContent partnerData={partner} />;
}
