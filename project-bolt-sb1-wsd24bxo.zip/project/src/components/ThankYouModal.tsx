import { X, MessageCircle } from 'lucide-react';

interface ThankYouModalProps {
  isOpen: boolean;
  onClose: () => void;
  whatsappUrl: string | null;
}

export function ThankYouModal({ isOpen, onClose, whatsappUrl }: ThankYouModalProps) {
  const handleWhatsAppClick = () => {
    if (whatsappUrl) {
      window.open(whatsappUrl, '_blank', 'noreferrer');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200">
          <h2 className="text-xl sm:text-2xl font-bold text-[#232D3E]">Vielen Dank!</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors p-2 -m-2"
          >
            <X size={20} className="sm:hidden" />
            <X size={24} className="hidden sm:block" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-5 sm:space-y-6">
          <div className="text-center">
            <div className="w-14 h-14 sm:w-16 sm:h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
              <svg
                className="w-7 h-7 sm:w-8 sm:h-8 text-green-500"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>

            <p className="text-base sm:text-lg text-gray-700 leading-relaxed px-2">
              Vielen Dank – das ist dein erster Schritt.<br />
              Wir melden uns zeitnah bei dir.
            </p>
          </div>

          <div className="space-y-2.5 sm:space-y-3">
            <button
              onClick={handleWhatsAppClick}
              disabled={!whatsappUrl}
              className={`w-full flex items-center justify-center gap-2.5 sm:gap-3 px-5 py-3.5 sm:px-6 sm:py-4 rounded-lg font-semibold text-base sm:text-lg transition-colors ${
                whatsappUrl
                  ? 'bg-[#25D366] hover:bg-[#1EBE57] text-white'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <MessageCircle size={20} className="sm:hidden flex-shrink-0" />
              <MessageCircle size={24} className="hidden sm:block flex-shrink-0" />
              <span className="text-sm sm:text-lg">{whatsappUrl ? 'Jetzt mit Berater chatten (WhatsApp)' : 'WhatsApp nicht verfügbar'}</span>
            </button>

            <button
              onClick={onClose}
              className="w-full px-5 py-3 sm:px-6 sm:py-3 text-sm sm:text-base border-2 border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
            >
              Schließen
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
