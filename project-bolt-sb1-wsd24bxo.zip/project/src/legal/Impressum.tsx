import { PartnerRecord } from '../data/partners';

interface ImpressumProps {
  partnerData: PartnerRecord;
}

export function Impressum({ partnerData }: ImpressumProps) {
  return (
    <div className="prose prose-sm max-w-none">
      <h3 className="text-xl font-bold text-[#232D3E] mb-4">Impressum</h3>

      <p className="text-sm text-gray-600 mb-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
        <strong>HINWEIS:</strong> Dieses Impressum gilt für von BestPrime bereitgestellte Landingpages externer Vertriebspartner.
      </p>

      <h4 className="text-lg font-semibold text-[#232D3E] mb-3">Angaben gemäß § 5 TMG</h4>

      <div className="mb-8">
        <p className="mb-2">
          <strong>BestPrime GmbH</strong><br />
          Leopoldstraße 31<br />
          80802 München<br />
          Deutschland
        </p>
        <p className="mb-2">
          Telefon: +49 89 277 827 052<br />
          E-Mail: <a href="mailto:office@bestprime.com" className="text-[#00A3DE] hover:underline">office@bestprime.com</a>
        </p>
        <p className="mb-2">
          <strong>Vertretungsberechtigter Geschäftsführer:</strong><br />
          Peter Grünewald
        </p>
        <p className="mb-2">
          <strong>Umsatzsteuer-Identifikationsnummer gemäß § 27a Umsatzsteuergesetz:</strong><br />
          DE344682275
        </p>
        <p className="mb-2">
          <strong>Registereintrag:</strong><br />
          Amtsgericht München<br />
          HRB 289352
        </p>
      </div>

      <div className="mb-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">Externer Vertriebspartner</h4>
        <p className="mb-4 text-gray-700">
          Diese Landingpage wird von BestPrime GmbH betrieben und im Rahmen der Vertriebstätigkeit genutzt durch:
        </p>

        <p className="mb-2">
          <strong>{partnerData.company_or_name}</strong>
          {partnerData.legal_representative && (
            <>
              <br />
              {partnerData.legal_representative}
            </>
          )}
          <br />
          {partnerData.street}<br />
          {partnerData.zip} {partnerData.city}
          {partnerData.country && (
            <>
              <br />
              {partnerData.country}
            </>
          )}
        </p>

        <p className="mb-2">
          {partnerData.phone && (
            <>
              Telefon: {partnerData.phone}<br />
            </>
          )}
          {partnerData.mobile && (
            <>
              Mobil: {partnerData.mobile}<br />
            </>
          )}
          E-Mail: <a href={`mailto:${partnerData.email}`} className="text-[#00A3DE] hover:underline">{partnerData.email}</a>
          {partnerData.website && (
            <>
              <br />
              Internet: <a href={`https://${partnerData.website.replace(/^https?:\/\//, '')}`} target="_blank" rel="noopener noreferrer" className="text-[#00A3DE] hover:underline">{partnerData.website.replace(/^https?:\/\//, '')}</a>
            </>
          )}
        </p>

        {(partnerData.register_court || partnerData.register_number) && (
          <p className="mb-2">
            <strong>Registereintrag:</strong>
            {partnerData.register_court && (
              <>
                <br />
                {partnerData.register_court}
              </>
            )}
            {partnerData.register_number && (
              <>
                <br />
                {partnerData.register_number}
              </>
            )}
          </p>
        )}

        {partnerData.vat_id && (
          <p className="mb-2">
            <strong>Umsatzsteuer-ID:</strong><br />
            {partnerData.vat_id}
          </p>
        )}

        {partnerData.tax_id && (
          <p className="mb-2">
            <strong>Steuernummer:</strong><br />
            {partnerData.tax_id}
          </p>
        )}

        <p className="text-sm text-gray-600 mt-4 pt-3 border-t border-gray-300">
          Der externe Vertriebspartner handelt als selbstständig tätiger Vertriebspartner und ist für eigene geschäftliche Handlungen verantwortlich.
        </p>

        <p className="text-sm text-gray-500 mt-2">
          Kundennummer: {partnerData.customer_number}
        </p>
      </div>

      <div className="mb-6">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">EU-Streitbeilegung</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit:{' '}
          <a href="https://ec.europa.eu/consumers/odr/" target="_blank" rel="noopener noreferrer" className="text-[#00A3DE] hover:underline">
            https://ec.europa.eu/consumers/odr/
          </a>
        </p>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Wir sind weder bereit noch verpflichtet, an einem Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
        </p>
      </div>

      <div className="mb-6">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">Haftungsausschluss</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Die Inhalte dieses Online-Angebots wurden sorgfältig und nach unserem aktuellen Wissensstand erstellt, dienen jedoch ausschließlich Informationszwecken und entfalten keine rechtlich bindende Wirkung, sofern es sich nicht um gesetzlich vorgeschriebene Informationen handelt.
        </p>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Wir behalten uns vor, Inhalte ganz oder teilweise zu ändern oder zu löschen, sofern keine vertraglichen Verpflichtungen entgegenstehen.
        </p>
      </div>

      <div className="mb-6">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">Haftung für Links</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Unsere Website enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Für diese fremden Inhalte übernehmen wir keine Gewähr. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter verantwortlich.
        </p>
      </div>

      <div className="mb-6">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">Urheberrecht</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechts bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers.
        </p>
      </div>

      <div className="mb-6">
        <h4 className="text-lg font-semibold text-[#232D3E] mb-3">Hinweis auf Rechtsverstöße</h4>
        <p className="mb-3 text-gray-700 leading-relaxed">
          Sollten Sie auf dieser Website Rechtsverstöße feststellen, bitten wir um einen entsprechenden Hinweis. Wir werden rechtswidrige Inhalte und Links nach Kenntniserlangung unverzüglich entfernen.
        </p>
      </div>

      <div className="text-sm text-gray-500 mt-8 pt-4 border-t border-gray-200">
        <p>Stand: {new Date().toLocaleDateString('de-DE', { year: 'numeric', month: 'long' })}</p>
      </div>
    </div>
  );
}
