export interface PartnerData {
  // Required fields
  customerNumber: string;
  companyOrName: string;
  street: string;
  zip: string;
  city: string;
  email: string;

  // Optional fields
  legalRepresentative?: string;
  country?: string;
  phone?: string;
  mobile?: string;
  website?: string;
  vatId?: string;
  taxId?: string;
  registerCourt?: string;
  registerNumber?: string;
  whatsappLink?: string;
  linkedinLink?: string;
  calendlyLink?: string;
  privacyContactName?: string;
  privacyContactEmail?: string;
}

// Example partner data - replace with actual values or fetch from API
export const partnerData: PartnerData = {
  customerNumber: "VP-12345",
  companyOrName: "Max Mustermann Consulting",
  legalRepresentative: "Max Mustermann",
  street: "Musterstraße 123",
  zip: "12345",
  city: "Musterstadt",
  country: "Deutschland",
  email: "kontakt@mustermann-consulting.de",
  phone: "+49 123 456789",
  mobile: "+49 160 123456789",
  website: "www.mustermann-consulting.de",
  vatId: "DE123456789",
  taxId: "12/345/67890",
  registerCourt: "Amtsgericht Musterstadt",
  registerNumber: "HRB 12345",
  calendlyLink: "https://calendly.com/mustermann",
  privacyContactName: "Max Mustermann",
  privacyContactEmail: "datenschutz@mustermann-consulting.de"
};
