import { PartnerRecord } from '../data/partners';

export type { PartnerRecord as PartnerData };

export function mapPartnerRecordToDisplayData(record: PartnerRecord) {
  return {
    customerNumber: record.customer_number,
    companyOrName: record.company_or_name || '',
    street: record.street || '',
    zip: record.zip || '',
    city: record.city || '',
    country: record.country || 'Deutschland',
    email: record.email || '',
    legalRepresentative: record.legal_representative || record.contact_name,
    phone: record.phone,
    mobile: record.mobile,
    website: record.website,
    vatId: record.vat_id,
    taxId: record.tax_id,
    registerCourt: record.register_court,
    registerNumber: record.register_number,
    whatsappLink: record.whatsapp_link,
    linkedInLink: record.linkedin_link,
    calendlyLink: record.calendly_link,
    privacyContactName: record.privacy_contact_name,
    privacyContactEmail: record.privacy_contact_email,
  };
}
