import { useState, useEffect } from 'react';
import {
  ArrowRight,
  X,
  CheckCircle2,
  XCircle,
  Zap,
  TrendingUp,
  Layers,
  Target,
  Clock,
  Phone,
  Lock,
  Building2,
  User
} from 'lucide-react';
import { FooterLegal } from './FooterLegal';
import { LeadFormModal } from './LeadFormModal';
import { ThankYouModal } from './ThankYouModal';
import { VideoModal } from './VideoModal';
import { PartnerRecord } from '../data/partners';
import { getWhatsAppUrl, getWhatsAppUrlWithMessage } from '../utils/contactUtils';

interface LandingPageContentProps {
  partnerData: PartnerRecord;
}

export function LandingPageContent({ partnerData }: LandingPageContentProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showAllTestimonials, setShowAllTestimonials] = useState(false);
  const [isLeadFormOpen, setIsLeadFormOpen] = useState(false);
  const [isThankYouOpen, setIsThankYouOpen] = useState(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [currentFlow, setCurrentFlow] = useState<'cta1' | 'cta2_video'>('cta1');
  const [showVideoThankYou, setShowVideoThankYou] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setIsMenuOpen(false);
    }
  };

  const whatsappUrl = getWhatsAppUrl(partnerData);
  const whatsappUrlWithMessage = getWhatsAppUrlWithMessage(partnerData);
  const videoUrl = import.meta.env.VITE_VIDEO_URL || partnerData.video_url || null;

  const handleCTA = () => {
    setCurrentFlow('cta1');
    setIsLeadFormOpen(true);
  };

  const handleCTA2 = () => {
    setCurrentFlow('cta2_video');
    setIsLeadFormOpen(true);
  };

  const handleLeadFormSuccess = () => {
    setIsLeadFormOpen(false);

    if (currentFlow === 'cta2_video') {
      setShowVideoThankYou(true);
      setIsVideoModalOpen(true);
    } else {
      setIsThankYouOpen(true);
    }
  };

  const handleVideoModalClose = () => {
    setIsVideoModalOpen(false);
    setShowVideoThankYou(false);
  };

  return (
    <div className="min-h-screen bg-white">
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-white shadow-lg' : 'bg-white/95 backdrop-blur-sm'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex-shrink-0">
              <img
                src="/bestprime_partner_logo.png"
                alt="BestPrime Partner"
                className="h-8 sm:h-10 w-auto"
              />
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => scrollToSection('home')}
                className="text-[#232D3E] hover:text-[#00A3DE] font-medium transition-colors"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection('system')}
                className="text-[#232D3E] hover:text-[#00A3DE] font-medium transition-colors"
              >
                Geschäftsmodell
              </button>
              <button
                onClick={() => scrollToSection('einstieg')}
                className="text-[#232D3E] hover:text-[#00A3DE] font-medium transition-colors"
              >
                Einstiegsmöglichkeiten
              </button>
              <button
                onClick={handleCTA}
                className="bg-[#00A3DE] hover:bg-[#008BBC] text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center gap-2"
              >
                Strategiegespräch buchen
                <ArrowRight size={18} />
              </button>
            </div>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-[#232D3E] p-2"
            >
              {isMenuOpen ? <X size={24} /> : (
                <div className="space-y-1.5">
                  <span className="block w-6 h-0.5 bg-[#232D3E]"></span>
                  <span className="block w-6 h-0.5 bg-[#232D3E]"></span>
                  <span className="block w-6 h-0.5 bg-[#232D3E]"></span>
                </div>
              )}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <div className="px-4 py-4 space-y-3">
              <button
                onClick={() => scrollToSection('home')}
                className="block w-full text-left px-4 py-2 text-[#232D3E] hover:bg-[#F5F7FA] rounded-lg transition-colors"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection('system')}
                className="block w-full text-left px-4 py-2 text-[#232D3E] hover:bg-[#F5F7FA] rounded-lg transition-colors"
              >
                Geschäftsmodell
              </button>
              <button
                onClick={() => scrollToSection('einstieg')}
                className="block w-full text-left px-4 py-2 text-[#232D3E] hover:bg-[#F5F7FA] rounded-lg transition-colors"
              >
                Einstiegsmöglichkeiten
              </button>
              <button
                onClick={handleCTA}
                className="block w-full bg-[#00A3DE] hover:bg-[#008BBC] text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Strategiegespräch buchen
              </button>
            </div>
          </div>
        )}
      </nav>

      <main className="pt-20">
        <section id="home" className="relative bg-gradient-to-b from-[#F5F7FA] to-white py-16 md:py-24 lg:py-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#232D3E] leading-tight mb-6">
                Wiederkehrende Einnahmen aus echtem Kundennutzen.<br />
                Nicht aus Recruiting.
              </h1>

              <p className="text-lg sm:text-xl text-gray-700 mb-8 leading-relaxed">
                Energieprodukt mit messbarem Vorteil für Endkunden –<br />
                und nutzungsbasierte Vergütung für jeden vermittelten Kunden.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-4">
                <button
                  onClick={handleCTA}
                  className="inline-flex items-center gap-3 bg-[#00A3DE] hover:bg-[#008BBC] text-white px-8 py-4 rounded-lg font-bold text-lg transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                >
                  Strategiegespräch buchen
                  <ArrowRight size={20} />
                </button>

                <button
                  onClick={handleCTA2}
                  className="inline-flex items-center gap-3 bg-white hover:bg-gray-50 text-[#00A3DE] border-2 border-[#00A3DE] px-8 py-4 rounded-lg font-semibold text-lg transition-colors"
                >
                  Video-Präsentation anfordern
                  <ArrowRight size={20} />
                </button>
              </div>

              <p className="text-sm text-gray-600 mb-4">
                kostenlos & unverbindlich
              </p>

              <div className="flex items-center justify-center gap-4 sm:gap-6 mb-12 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Clock size={16} className="text-[#F8971C]" />
                  <span>ca. 20–30 Minuten</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone size={16} className="text-[#F8971C]" />
                  <span>Telefon oder Video</span>
                </div>
                <div className="flex items-center gap-2">
                  <Lock size={16} className="text-[#F8971C]" />
                  <span>vertraulich</span>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-3 mb-8 text-left">
                <div className="bg-white p-4 md:p-3 rounded-xl shadow-md md:shadow-sm border-2 md:border border-[#00A3DE] md:border-gray-100 sm:col-span-2">
                  <div className="flex items-start gap-3 md:gap-2">
                    <div className="flex-shrink-0 w-12 h-12 md:w-9 md:h-9 bg-[#00A3DE] md:bg-[#00A3DE]/10 rounded-lg flex items-center justify-center">
                      <TrendingUp className="text-white md:text-[#00A3DE]" size={24} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#232D3E] text-base md:text-sm mb-1">Nutzungsbasierte Vergütung</h3>
                      <p className="text-gray-600 text-sm md:text-xs">Monatliche Einnahmen aus echter Produktnutzung deiner Kunden.</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-3 rounded-xl shadow-sm border border-gray-100 opacity-80 md:opacity-100">
                  <div className="flex items-start gap-2">
                    <div className="flex-shrink-0 w-9 h-9 bg-[#00A3DE]/10 rounded-lg flex items-center justify-center">
                      <Target className="text-[#00A3DE]" size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#232D3E] text-sm mb-1">Langfristige Kundenbeziehungen</h3>
                      <p className="text-gray-600 text-xs hidden md:block">Aufbau stabiler Einnahmequellen statt Einmalabschlüsse.</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-3 rounded-xl shadow-sm border border-gray-100 opacity-80 md:opacity-100">
                  <div className="flex items-start gap-2">
                    <div className="flex-shrink-0 w-9 h-9 bg-[#00A3DE]/10 rounded-lg flex items-center justify-center">
                      <Zap className="text-[#00A3DE]" size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#232D3E] text-sm mb-1">Planbare Einnahmen</h3>
                      <p className="text-gray-600 text-xs hidden md:block">Vorhersehbarer Verdienst durch Bestandskunden.</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-3 rounded-xl shadow-sm border border-gray-100 opacity-80 md:opacity-100 sm:col-span-2">
                  <div className="flex items-start gap-2">
                    <div className="flex-shrink-0 w-9 h-9 bg-[#00A3DE]/10 rounded-lg flex items-center justify-center">
                      <Layers className="text-[#00A3DE]" size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#232D3E] text-sm mb-1">Kundengetriebene Weiterempfehlung</h3>
                      <p className="text-gray-600 text-xs hidden md:block">Zufriedene Kunden empfehlen weiter – ohne Druck.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-[#F8971C]/20 rounded-lg p-4 md:p-6 mb-8">
                <h3 className="text-base md:text-xl font-bold text-[#232D3E] mb-2 md:mb-3">Echtes Energieprodukt. Keine Mitgliedsgebühren. Kein Recruiting-Zwang.</h3>
                <p className="text-gray-600 text-sm md:text-base mb-3 md:mb-4">
                  Lizenziertes Energieprodukt mit messbarem Kundenvorteil – kein MLM, kein Krypto, kein Coaching-Programm.
                </p>
                <p className="text-gray-600 text-sm md:text-base">
                  <strong>Vergütung:</strong> Ausschließlich aus realer Produktnutzung vermittelter Kunden – keine Bonus-Kaskaden.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="system" className="py-28 md:py-28 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#232D3E] text-center mb-12">
                Wie funktioniert das Geschäftsmodell?
              </h2>

              <div className="grid sm:grid-cols-2 gap-4 sm:gap-4 mb-10 md:mb-12">
                <div className="bg-[#F5F7FA] p-4 md:p-4 rounded-xl">
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-9 h-9 bg-[#00A3DE] rounded-lg flex items-center justify-center">
                      <CheckCircle2 className="text-white" size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#232D3E] text-sm mb-1">Echtes Energieprodukt</h3>
                      <p className="text-gray-600 text-xs leading-snug">Lizenzierte Energielösung mit nachweisbarem Sparpotenzial für Privathaushalte</p>
                    </div>
                  </div>
                </div>

                <div className="bg-[#F5F7FA] p-4 rounded-xl">
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-9 h-9 bg-[#00A3DE] rounded-lg flex items-center justify-center">
                      <CheckCircle2 className="text-white" size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#232D3E] text-sm mb-1">Du vermittelst Endkunden</h3>
                      <p className="text-gray-600 text-xs leading-snug">Deine Aufgabe: Kunden für das Energieprodukt gewinnen</p>
                    </div>
                  </div>
                </div>

                <div className="bg-[#F5F7FA] p-4 rounded-xl">
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-9 h-9 bg-[#00A3DE] rounded-lg flex items-center justify-center">
                      <CheckCircle2 className="text-white" size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#232D3E] text-sm mb-1">Monatliche Vergütung</h3>
                      <p className="text-gray-600 text-xs leading-snug">Du erhältst Provision aus der Produktnutzung deiner vermittelten Kunden</p>
                    </div>
                  </div>
                </div>

                <div className="bg-[#F5F7FA] p-4 rounded-xl">
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-9 h-9 bg-[#00A3DE] rounded-lg flex items-center justify-center">
                      <CheckCircle2 className="text-white" size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#232D3E] text-sm mb-1">Wiederkehrende Einnahmen</h3>
                      <p className="text-gray-600 text-xs leading-snug">Solange Kunden das Produkt nutzen, erhältst du Vergütung</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <button
                  onClick={handleCTA}
                  className="inline-flex items-center gap-2 md:gap-3 bg-white md:bg-[#00A3DE] hover:bg-[#00A3DE] md:hover:bg-[#008BBC] text-[#00A3DE] md:text-white border-2 border-[#00A3DE] md:border-0 px-6 md:px-8 py-3 md:py-4 rounded-lg font-semibold md:font-bold text-base md:text-lg transition-colors"
                >
                  Strategiegespräch buchen
                  <ArrowRight size={18} className="md:hidden" />
                  <ArrowRight size={20} className="hidden md:block" />
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-28 md:py-24 bg-gradient-to-b from-white to-[#F5F7FA]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#232D3E] text-center mb-6 md:mb-6 leading-tight">
                Warum entsteht hier echter Kundennutzen?
              </h2>

              <p className="text-center text-gray-700 text-base md:text-lg mb-10 md:mb-16">
                Wiederkehrende Einnahmen entstehen nur, wenn Kunden echten Mehrwert erhalten und das Produkt tatsächlich nutzen.
              </p>

              <div className="grid lg:grid-cols-2 gap-5 md:gap-8 mb-7 md:mb-10">
                <div className="bg-white rounded-xl border-2 border-[#00A3DE]/20 p-5 md:p-8">
                  <h3 className="text-xl md:text-2xl font-bold text-[#232D3E] mb-6 flex items-center gap-2">
                    <User className="text-[#00A3DE]" size={28} />
                    Für Endkunden
                  </h3>
                  <div className="space-y-3 md:space-y-4">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700 text-sm md:text-base">Möglichkeit, Stromkosten im Optimalfall vollständig zu kompensieren</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700 text-sm md:text-base">Keine Verhaltensänderung notwendig</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700 text-sm md:text-base">Nutzung läuft automatisch im Alltag</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700 text-sm md:text-base">Echter finanzieller Vorteil, kein Bonus- oder Punktesystem</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl border-2 border-[#00A3DE]/20 p-5 md:p-8">
                  <h3 className="text-xl md:text-2xl font-bold text-[#232D3E] mb-6 flex items-center gap-2">
                    <Building2 className="text-[#00A3DE]" size={28} />
                    Für Händler
                  </h3>
                  <div className="space-y-3 md:space-y-4">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700 text-sm md:text-base">Neue Kunden durch Empfehlungen statt Werbung</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700 text-sm md:text-base">Höhere Kundenbindung</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700 text-sm md:text-base">Zusätzlicher Umsatz ohne Fixkosten</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700 text-sm md:text-base">Teilnahme ohne Risiko oder Vertragszwang</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-[#00A3DE]/5 border-l-4 border-[#00A3DE] rounded-r-lg p-5 md:p-6">
                <p className="text-[#232D3E] text-base md:text-lg font-medium leading-relaxed">
                  Weil Endkunden echten Mehrwert erhalten und Händler profitieren, nutzen Kunden das Produkt dauerhaft –
                  und genau diese Nutzung ist die Grundlage deiner monatlichen Vergütung.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="video-section" className="py-28 md:py-24 bg-[#F5F7FA]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#232D3E] text-center mb-6 md:mb-4 leading-tight">
                60 Sekunden. Echte Vertriebspartner.
              </h2>

              <p className="text-center text-gray-700 text-lg mb-10">
                Warum sie heute planbare Einnahmen haben – statt ständig neue Deals jagen zu müssen.
              </p>

              <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-8">
                <div className="relative bg-gray-900 aspect-video">
                  <video
                    className="w-full h-full"
                    controls
                    preload="metadata"
                    crossOrigin="anonymous"
                    poster="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1280 720'%3E%3Crect fill='%23232D3E' width='1280' height='720'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' fill='%23ffffff' font-size='24' font-family='system-ui, sans-serif'%3EVIDEO PLACEHOLDER%3C/text%3E%3C/svg%3E"
                  >
                    <source src="/video/partner-testimonial.mp4" type="video/mp4" />
                    <track
                      kind="subtitles"
                      src="/video/partner-testimonial.vtt"
                      srcLang="de"
                      label="Deutsch"
                      default
                    />
                    Ihr Browser unterstützt das Video-Element nicht.
                  </video>
                </div>
              </div>

              <div className="text-center">
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-3">
                  <button
                    onClick={handleCTA}
                    className="inline-flex items-center gap-3 bg-[#00A3DE] hover:bg-[#008BBC] text-white px-10 md:px-8 py-4 rounded-lg font-bold text-lg transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                  >
                    Strategiegespräch buchen
                    <ArrowRight size={22} className="md:hidden" />
                    <ArrowRight size={20} className="hidden md:block" />
                  </button>
                  <button
                    onClick={handleCTA2}
                    className="inline-flex items-center gap-3 bg-white hover:bg-gray-50 text-[#00A3DE] border-2 border-[#00A3DE] px-10 md:px-8 py-4 rounded-lg font-semibold text-lg transition-colors"
                  >
                    Video-Präsentation anfordern
                    <ArrowRight size={22} className="md:hidden" />
                    <ArrowRight size={20} className="hidden md:block" />
                  </button>
                </div>
                <p className="text-sm text-gray-600">
                  kostenlos & unverbindlich
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="einstieg" className="py-28 md:py-24 bg-gradient-to-b from-[#F5F7FA] to-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#232D3E] text-center mb-10 md:mb-16">
                Zwei Einstiegsmöglichkeiten
              </h2>

              <div className="grid lg:grid-cols-2 gap-6 md:gap-8 mb-10 md:mb-12">
                <div className="bg-white rounded-2xl shadow-lg p-6 md:p-8 border-2 border-[#00A3DE]">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-14 h-14 bg-[#00A3DE] rounded-xl flex items-center justify-center">
                      <Building2 className="text-white" size={28} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-[#232D3E]">Variante A</h3>
                      <p className="text-[#00A3DE] font-semibold">Für bestehende Vertriebe</p>
                    </div>
                  </div>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700">Team bleibt bestehen</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700">Läuft parallel zum Bestehendem</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700">Zusatzeinkommen ohne Reorganisation</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#00A3DE] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700">Nutzt deine Reichweite</span>
                    </div>
                  </div>

                  <div className="bg-[#F5F7FA] rounded-lg p-4 text-sm text-gray-600">
                    Ideal für Teams, Agenturen, Team- oder Franchise-Vertriebe.
                  </div>
                </div>

                <div className="bg-white rounded-2xl shadow-lg p-6 md:p-8 border-2 border-[#008BBC]">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-14 h-14 bg-[#008BBC] rounded-xl flex items-center justify-center">
                      <User className="text-white" size={28} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-[#232D3E]">Variante B</h3>
                      <p className="text-[#008BBC] font-semibold">Für Solo-Vertriebler</p>
                    </div>
                  </div>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#008BBC] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700">Kein Team notwendig</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#008BBC] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700">Kein Vorwissen erforderlich</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#008BBC] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700">Kontakte reichen aus</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-[#008BBC] flex-shrink-0 mt-0.5" size={20} />
                      <span className="text-gray-700">Wächst mit dir</span>
                    </div>
                  </div>

                  <div className="bg-[#F5F7FA] rounded-lg p-4 text-sm text-gray-600">
                    Ideal für Einzelvertriebler, Selbstständige, Networker ohne Team.
                  </div>
                </div>
              </div>

              <div className="bg-[#F8971C]/10 border-2 border-[#F8971C] rounded-xl p-5 text-center mb-8">
                <p className="text-base font-semibold text-[#232D3E]">
                  Beide Wege funktionieren nach demselben Prinzip – der Unterschied liegt nur im Startpunkt.
                </p>
              </div>

              <div className="text-center">
                <button
                  onClick={handleCTA}
                  className="inline-flex items-center gap-3 bg-[#00A3DE] hover:bg-[#008BBC] text-white px-8 py-4 rounded-lg font-bold text-lg transition-colors"
                >
                  Strategiegespräch buchen
                  <ArrowRight size={20} />
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-28 md:py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl sm:text-4xl font-bold text-[#232D3E] text-center mb-8 md:mb-12">
                Für wen das ist
              </h2>

              <div className="grid md:grid-cols-2 gap-5 md:gap-8 mb-12">
                <div className="bg-green-50 border-2 border-green-500 rounded-xl p-6 md:p-8">
                  <h3 className="text-xl font-bold text-[#232D3E] mb-6 flex items-center gap-2">
                    <CheckCircle2 className="text-green-500" size={24} />
                    Geeignet für
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-green-500 flex-shrink-0 mt-0.5" size={18} />
                      <span className="text-gray-700">Unternehmer & Selbstständige</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-green-500 flex-shrink-0 mt-0.5" size={18} />
                      <span className="text-gray-700">Vertriebler mit Kunden, Kontakten oder Teams</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="text-green-500 flex-shrink-0 mt-0.5" size={18} />
                      <span className="text-gray-700">Menschen mit unternehmerischem Denken</span>
                    </div>
                  </div>
                </div>

                <div className="bg-red-50 border-2 border-red-500 rounded-xl p-6 md:p-8">
                  <h3 className="text-xl font-bold text-[#232D3E] mb-6 flex items-center gap-2">
                    <XCircle className="text-red-500" size={24} />
                    Nicht geeignet für
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <XCircle className="text-red-500 flex-shrink-0 mt-0.5" size={18} />
                      <span className="text-gray-700">Schnell-reich-Mentalität</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <XCircle className="text-red-500 flex-shrink-0 mt-0.5" size={18} />
                      <span className="text-gray-700">reine Abschlusssammler</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <XCircle className="text-red-500 flex-shrink-0 mt-0.5" size={18} />
                      <span className="text-gray-700">Menschen ohne Bereitschaft zum Aufbau</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-28 md:py-24 bg-[#F5F7FA]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl sm:text-4xl font-bold text-[#232D3E] text-center mb-8 md:mb-12">
                Echte Partnerstimmen
              </h2>

              <div className="grid md:grid-cols-2 gap-5 md:gap-6 mb-5 md:mb-6">
                <div className="bg-white rounded-xl p-5 md:p-6 shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-[#00A3DE] rounded-full flex items-center justify-center text-white font-bold text-lg">
                      MS
                    </div>
                    <div>
                      <div className="font-bold text-[#232D3E]">Michael Schmidt</div>
                      <div className="text-sm text-gray-600">Hamburg</div>
                    </div>
                  </div>
                  <p className="text-gray-700 leading-relaxed">
                    "Endlich kann ich mein Business planbar aufbauen. Die wiederkehrenden
                    Einnahmen aus der Produktnutzung meiner Kunden schaffen Stabilität."
                  </p>
                </div>

                <div className="bg-white rounded-xl p-5 md:p-6 shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-[#00A3DE] rounded-full flex items-center justify-center text-white font-bold text-lg">
                      JM
                    </div>
                    <div>
                      <div className="font-bold text-[#232D3E]">Julia Meier</div>
                      <div className="text-sm text-gray-600">München</div>
                    </div>
                  </div>
                  <p className="text-gray-700 leading-relaxed">
                    "Das Geschäftsmodell funktioniert. Kein leeres Versprechen, sondern ein Produkt,
                    das Kunden tatsächlich nutzen – und das langfristig trägt."
                  </p>
                </div>

                <div className={`bg-white rounded-xl p-5 md:p-6 shadow-sm md:block ${showAllTestimonials ? 'block' : 'hidden'}`}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-[#00A3DE] rounded-full flex items-center justify-center text-white font-bold text-lg">
                      TW
                    </div>
                    <div>
                      <div className="font-bold text-[#232D3E]">Thomas Weber</div>
                      <div className="text-sm text-gray-600">Berlin</div>
                    </div>
                  </div>
                  <p className="text-gray-700 leading-relaxed">
                    "Ich habe mein bestehendes Vertriebsteam integriert – ohne Neustart,
                    ohne Umstellung. Genial einfach."
                  </p>
                </div>

                <div className={`bg-white rounded-xl p-5 md:p-6 shadow-sm md:block ${showAllTestimonials ? 'block' : 'hidden'}`}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-[#00A3DE] rounded-full flex items-center justify-center text-white font-bold text-lg">
                      SK
                    </div>
                    <div>
                      <div className="font-bold text-[#232D3E]">Sandra Klein</div>
                      <div className="text-sm text-gray-600">Frankfurt</div>
                    </div>
                  </div>
                  <p className="text-gray-700 leading-relaxed">
                    "Als Solo-Selbstständige war ich skeptisch. Aber das Geschäftsmodell ist so konzipiert,
                    dass es auch ohne großes Team funktioniert."
                  </p>
                </div>
              </div>

              <div className="text-center mb-12 md:hidden">
                <button
                  onClick={() => setShowAllTestimonials(!showAllTestimonials)}
                  className="text-[#00A3DE] font-semibold text-sm hover:underline"
                >
                  {showAllTestimonials ? 'Weniger anzeigen' : 'Mehr anzeigen'}
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-28 md:py-24 bg-gradient-to-b from-[#232D3E] to-[#1a2332]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 md:mb-6">
                Wiederkehrende Einnahmen werden früh aufgebaut.<br />
                Später reden die meisten nur darüber.
              </h2>

              <p className="text-xl text-white/80 mb-12">
                Kläre unverbindlich, ob BestPrime zu dir passt.
              </p>

              <button
                onClick={handleCTA}
                className="inline-flex items-center gap-3 md:gap-3 bg-[#00A3DE] hover:bg-[#008BBC] text-white px-12 md:px-10 py-5 md:py-5 rounded-lg font-bold text-xl md:text-xl transition-all shadow-2xl hover:shadow-3xl transform hover:-translate-y-1 mb-8 w-full md:w-auto"
              >
                Strategiegespräch buchen
                <ArrowRight size={26} className="md:hidden" />
                <ArrowRight size={24} className="hidden md:block" />
              </button>

              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 max-w-2xl mx-auto">
                <p className="text-white/90 leading-relaxed">
                  <strong>Kein Kaufdruck. Keine Verpflichtung.</strong><br />
                  Das Gespräch dient ausschließlich zur Klärung, ob es passt.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#F5F7FA] py-12 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <img
              src="/bestprime_partner_logo.png"
              alt="BestPrime Partner"
              className="h-10 w-auto mx-auto mb-6"
            />
            <p className="text-gray-600 text-sm mb-4">
              &copy; {new Date().getFullYear()} BestPrime. Energie. Vertrauen. Nachhaltigkeit.
            </p>
            <FooterLegal partnerData={partnerData} />
          </div>
        </div>
      </footer>

      <LeadFormModal
        isOpen={isLeadFormOpen}
        onClose={() => setIsLeadFormOpen(false)}
        onSuccess={handleLeadFormSuccess}
        customerNumber={partnerData.customer_number}
        partnerName={partnerData.company_or_name || ''}
        flow={currentFlow}
      />

      <ThankYouModal
        isOpen={isThankYouOpen}
        onClose={() => setIsThankYouOpen(false)}
        whatsappUrl={whatsappUrl}
      />

      <VideoModal
        isOpen={isVideoModalOpen}
        onClose={handleVideoModalClose}
        videoUrl={videoUrl}
        whatsappUrl={whatsappUrlWithMessage}
        showThankYou={showVideoThankYou}
      />
    </div>
  );
}
