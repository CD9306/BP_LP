export function WelcomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F5F7FA] to-white flex items-center justify-center px-4">
      <div className="max-w-2xl text-center">
        <img
          src="/bestprime_partner_logo.png"
          alt="BestPrime Partner"
          className="h-16 w-auto mx-auto mb-8"
        />
        <h1 className="text-4xl font-bold text-[#232D3E] mb-6">
          BestPrime Vertriebspartner
        </h1>
        <p className="text-xl text-gray-700 mb-8">
          Bitte rufen Sie die Seite mit Ihrer persönlichen Kundennummer auf:
        </p>
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
          <code className="text-lg text-[#00A3DE] font-mono">
            /#/vp/&#123;customerNumber&#125;
          </code>
        </div>
        <p className="text-gray-600">
          Beispiel: <span className="font-mono text-[#00A3DE]">/#/vp/office</span>
        </p>
      </div>
    </div>
  );
}
