import { Routes, Route } from 'react-router-dom';
import { PartnerDataProvider } from './context/PartnerDataContext';
import { WelcomePage } from './pages/WelcomePage';
import { PartnerLandingPage } from './pages/PartnerLandingPage';

function App() {
  return (
    <PartnerDataProvider>
      <Routes>
        <Route path="/" element={<WelcomePage />} />
        <Route path="/vp/:customerNumber" element={<PartnerLandingPage />} />
      </Routes>
    </PartnerDataProvider>
  );
}

export default App;
